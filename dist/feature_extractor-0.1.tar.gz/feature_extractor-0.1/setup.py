from setuptools import setup

setup(name='feature_extractor',
      version='0.1',
      description='extract features from Image, Audio, Face',
      author='JasonLi',
      author_email='zl2528@columbia.edu',
      license='HB',
      packages=['Feature_extractor'],
      zip_safe=False)
